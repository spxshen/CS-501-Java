import java.util.Scanner;
public class C7E9findSmallestElement {
    
	public static void main(String[] args){
    Scanner in=new Scanner(System.in);
    int repeatIntnumber = 1;
    while (repeatIntnumber == 1) {
    double[] list=new double[10];
    System.out.println("Please enter ten numbers:");
    for(int a=0;a<list.length;a++)
    {
    	list[a]=in.nextDouble();
    
    }   
        System.out.println("\nThe ten numbers in the array is shown as below:");
        display(list);
        System.out.println("The minimum number is: "+min(list));
        System.out.println("The index of smallest number is: "+indexOfSmallestElement(list));
    
    System.out.println("Do you want to repeat the program (enter 1 for yes or 0 for no? ): ");
    repeatIntnumber = in.nextInt();
    if ( repeatIntnumber == 0)
 	   in.close();
    }
	}

  public static double min(double[] array){//This is what 7.9 is. As same as func interface in the textbook
        double x=array[0];
        for(int i=1;i<array.length;i++){
            if(array[i]<x)
                x=array[i];  
        }
        return x;
    }

    public static int indexOfSmallestElement(double[] array){//This is what 7.10 is. As same as func interface in the textbook
        int index=0;//also if there is more than one elements in the array just return the smallest element
        for(int i=1;i<array.length;i++){
            if(array[i]<array[index])
                index=i;
        }
        
        return index;

    }

	public static void display(double[] list)//just for display by a function to implement
	{   
		System.out.print("[");
		for(int i=0;i<10;i++)
		{
			System.out.print(list[i]);
			if(i!=9)
			System.out.print(", ");
		}
	    System.out.println("]");
		
	}
}
