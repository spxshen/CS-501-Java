import java.util.Scanner;
public class C5E20displayPrimeNumber {
public static void main(String[] args) {
    int number=2;//number from which to find 50 prime numbers
    int primeNum=0;//count to 50 
    int temp=0;
    int count=0;
    int repeatIntnumber = 1;//for loop
    Scanner input=new Scanner(System.in);
    System.out.print("The first 50 primes numbers between 2 and 1000 are shown below:");
    for(primeNum=0;primeNum<50;number++) //number increment one each time for testing     
    {
	     if(isprime(number))//use function 
	     {   
	    	if(primeNum%8==0)
	    		 System.out.println();     
	    	System.out.print(number+" ");//display
	    	 primeNum++; //count prime numbers till 50
	     }
    		
    }		
 
    for(number=2;number<=1000;number++)//to find out how many numbers of primes less than 1000 
    {
    	if(isprime(number))
         	count++;  	
    }
	
    int[] array=new int[count]; //then allocate the memory of array which includes all the primes numbers below 1000
    for(number=2;number<=1000;number++)//to find out how many primes less than 1000
    {   
    	if(isprime(number))
        {
    	 array[temp]=number;
         temp++;
        }
    }  
   // displayinarray(array);//you can display the whole array easily if you want
    while(repeatIntnumber == 1) //a repeat loop
    {
    System.out.println();
    System.out.println("Enter a number to test whether it's a prime in the array:");
    searchfunction(array);// encapsulation for search
    System.out.println("Continue test program (enter 1 for yes or 0 for no? ): ");
    repeatIntnumber = input.nextInt();
    if ( repeatIntnumber == 0)
 	   input.close();  
    }   
}

public static boolean isprime(int n)
{
for(int j=2;j<=Math.sqrt(n);j++)
{
	if(n%j==0) 	return false;
	
}
return true;//only when n cannot divided by j after for loop is prime
}

 public static int linearSearch(int[] list, int key)
 {
 for (int i = 0; i < list.length; i++)//searching loop
 {
     if (key == list[i])
     return i;
 }
	 return -1;
}
 

public static void searchfunction(int [] array)
{   Scanner in=new Scanner(System.in);
       int input=in.nextInt();
       System.out.println("You entered the number:"+input);
    if(linearSearch(array,input)==-1)
    	System.out.println(input+" is not in the array and it is not prime number less than 1000!");
    else
    	System.out.println(array[linearSearch(array,input)]+" is in the array and it is a prime!");
	
}

//This doesn't include in the requirement But I think it is useful to check all the numbers in the array
/*public static void displayinarray(int[] a) 
{   System.out.println();
	System.out.println("Display first primes numbers less than 1000 in the array:");
	for(int i=0;i<a.length;i++)
	{  
	if((i+1)%8==0)
		System.out.println(a[i]);
	else
		System.out.print(a[i]+" ");
	}
	
}/*This doesn't include in the requirement But I think it is necessary*/

}
