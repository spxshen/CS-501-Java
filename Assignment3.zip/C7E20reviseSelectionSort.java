import java.util.Scanner;
public class C7E20reviseSelectionSort {
	public static void main(String[] args)
	{
        Scanner in=new Scanner(System.in);
		double []sort=new double[10]; 
		int repeatIntnumber = 1;//for loop
		while (repeatIntnumber == 1) {
		System.out.println("Enter ten numbers in one array:");
		for(int i=0;i<10;i++)
			{
			   sort[i]=in.nextDouble();
			}
		System.out.println("\nThe current array is shown as below:");
		display(sort);
		double[] SortedArray=reviseSelectionSort(sort);
		System.out.println("\nThe sorted array is shown as below:");
		display(SortedArray);
		System.out.println("Do you want to repeat the program (enter 1 for yes or 0 for no? ): ");
        repeatIntnumber = in.nextInt();
        if ( repeatIntnumber == 0)
	        in.close();
	    }
	}
	public static double[] reviseSelectionSort(double[] list)
	{
        for(int i=list.length-1;i>=0;i--)
        {
            double currentMax=list[i];
            int currentIndexMax=i;
            for(int j=i-1;j>=0;j--)
            {
                if(list[j]>currentMax)
                {
                    currentMax=list[j];
                    currentIndexMax=j;
                }
            }
            if(currentIndexMax!=i)
            {
                list[currentIndexMax]=list[i];
                list[i]=currentMax;
            }
        }
        return list;
    }

	public static void display(double[] list)//just for display by a function to implement
	{   
		System.out.print("[");
		for(int i=0;i<10;i++)
		{
			System.out.print(list[i]);
			if(i!=9)
			System.out.print(", ");
		}
	    System.out.println("]");
		
	}
}

