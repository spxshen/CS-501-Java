import java.util.Scanner;
public class C3E27pointsInTriangle {
    public static void main(String args[]){
    	Scanner in=new Scanner(System.in);
    	double x,y;
    	System.out.println( "The coordinates of the given right triangle is ( 0, 0 ), ( 0, 100 ),( 200, 0 ) " );
    	System.out.println("input an point to determined whether it is inside the triangle ");
    	System.out.println("input X-coordinate and y-coordinate one by one:");
    	x=in.nextDouble();
    	y=in.nextDouble();
    	System.out.println("The point you inputted is ("+x+","+y+")");
    	if(x<0 || y<0)//according to three given points for the triangle. Both x-coordinate and y must be greater than 0
    	{
    		System.out.println("The point is not in the triangle");
    		
    	}
    	else if(y<-0.5*x+100)//The hypotenuse of this right triangle is like a linear equation which is y=-0.5*x+100
    	{
    		
    		System.out.println("The point is in the triangle.");
                
    	}
    	else
    	{
    		
    		System.out.println("The point is not in the triangle.");
    		
    	}
    		
    }
}
    
       