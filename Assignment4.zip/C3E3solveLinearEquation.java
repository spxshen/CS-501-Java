//by using 10th Edition
import java.util.Scanner;
public class C3E3solveLinearEquation {

	public static void main(String[] args) {
    double a,b,c,d,e,f,x,y;//define variables
	Scanner in=new Scanner(System.in);//make an object for further input
	System.out.println("The Linear Equations are shown below:");//just for display
 	System.out.println("ax+by=e"+'\n'+"cx+dy=f");
 	System.out.println("Enter a, b, c, d, e, f:");
	a=in.nextDouble();//get in
	b=in.nextDouble();
 	c=in.nextDouble();
	d=in.nextDouble();
	e=in.nextDouble();
	f=in.nextDouble();
	System.out.println("a="+a+" b="+b+" c="+c+" d="+d+" e="+e+" f="+f);
	System.out.println("The Linear Equations are shown below");
	System.out.println(a+"x+"+b+"y="+e+'\n'+c+"x+"+d+"y="+f);
	//echo what you did input above
	if(a*d-b*c==0){
         System.out.println("The equation has no solution.");//as same as requirement
     }
     else{
         x=(e*d-b*f)/(a*d-b*c);
         y=(a*f-e*c)/(a*d-b*c);
         System.out.println("x is "+x+" and y is "+y);
     }
 
 	
	  }
 	
	}



