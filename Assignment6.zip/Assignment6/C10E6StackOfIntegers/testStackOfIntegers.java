import java.util.*;
public class testStackOfIntegers 
{
 public static void main(String[] args)
 { 
	 
    Scanner input = new Scanner(System.in);
	int repeatIntnumber = 1;
	while (repeatIntnumber == 1) 
	{
    System.out.println("The program is going to display all the prime less than 120 in decreasing order by using stack to implement "); 
    StackOfIntegers stack=new StackOfIntegers(countprime(120));//this is exact allocate space for array
    for(int i=2;i<120;i++)
    {
       if(isPrime(i))
       {
           stack.push(i);//push in
       }
    }
System.out.println("Prime numbers less than 120 are displayed in reverse order are shown below:");
while(!stack.empty())
{
    System.out.println(stack.pop()+" ");//last in first out so in this way display numbers in reverse order
} 
      
    System.out.print("Repeat display the result (enter 1 for yes or 0 for no? ): ");
    repeatIntnumber = input.nextInt();
        if ( repeatIntnumber == 0)
	               input.close();
}

} 
 
 public static int countprime(int bunch)
 {
	 boolean flag;
	 int count=0;
	 for(int j=2;j<=bunch;j++)
	 {   
		 flag=true;//set default current number is prime
		 for(int i=2;i<Math.sqrt(j);i++)
		 {
			 if(j%i==0)
			 { flag=false;
			   break;
			 }//if not prime just break current loop
		 }
	     if(flag)
	      count++;//to count how many prime are they less than bunch
	 }

     return count;
 
 }

 public static boolean isPrime(int number)//a function is used for testing whether a number is a prime or not
 {
	 for(int i=2;i<Math.sqrt(number);i++)
	 {
		 
		 if(number%i==0) return false;
		 
	 }
	 
	 return true;
 }
 
 
 
 
}
	 


