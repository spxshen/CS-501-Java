public class StackOfIntegers {
private int[]elements;//elements in stack store in the array 
private int size;
public static final int default_cap=16;//max capacity is 16

public StackOfIntegers()
{
this(default_cap);	
	
}
	
public StackOfIntegers(int x)
{
	
	elements=new int[x];//construct a stack with max capacity
	
}
public void push(int x)//push in
{
	if(size>=elements.length)
	{
	int[] temp=new int[elements.length*2];//if current array is not enough then create a new array of twice its size
	System.arraycopy(elements, 0, temp, 0, elements.length);//copy 
    elements=temp;//use temp to cover elements	
	}
	elements[size]=x;//push x to elements
	size++;//then size increment one
}

public int pop() //pop out
{
	
	return elements[--size];//size decrease one then return the poped out element
	

}

public int peek()
{
	
	return elements[size-1];//get the top element
}

public boolean empty()
{ 
	return size==0;//return true if stack is empty
	
}
public int getSize()//return how many elements in the array
{
	
   return size;
}



}
