import java.util.*;

public class C10E4testMypoint {
public static void main(String[] args)
{    

	Scanner input = new Scanner(System.in);
	int repeatIntnumber = 1;
	while (repeatIntnumber == 1) 
	{
	System.out.println("The program is goint to display the distance between points(0,0) and (10.30.5)");
	MyPoint p1=new MyPoint();//build accordingly
	System.out.println("one point is ("+p1.getX()+","+p1.getY()+")");
	MyPoint p2=new MyPoint(10,30.5);
	System.out.println("other point is ("+p2.getX()+","+p2.getY()+")");
	double dis=p1.distance(p2);//to use distance function
	System.out.println("The distance between (0,0) and (10,30.5) is "+dis+"\n");
    System.out.print("Repeat display the result (enter 1 for yes or 0 for no? ): ");
    repeatIntnumber = input.nextInt();
        if ( repeatIntnumber == 0)
	               input.close();
	
	}	
}
}
