public class MyPoint {

private double x;//x coord
private double y;//y coord
public MyPoint()//no arguments constructor
{
	x=0;
	y=0;
	
}
public MyPoint(double a,double b)//constructor with arguments
{
	x=a;
	y=b;
	
}
public double getX()
{
	return x; //get to know what is x
}
	
public double getY()
{
	return y;//likewise
}
public double distance(MyPoint p)//return the distance from this point to MyPoint type
{
    return Math.sqrt(Math.pow(this.x-p.x,2)+Math.pow(this.y-p.y,2));

}
public double distance(double x,double y)//from this point to another point
{
    return Math.sqrt(Math.pow(this.x-x,2)+Math.pow(this.y-y,2));
}


}

