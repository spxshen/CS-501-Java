
public class IllegalTriangleException extends Exception {
   private double side_1,side_2,side_3;//3 sides to form a triagnle
   public IllegalTriangleException(double a,double b,double c)//constructor
   {
	  super("Cannot create a triangle from the 3 sides");
      this.side_1=a;
      this.side_1=b;
      this.side_1=c;
   }
   public IllegalTriangleException(double a)
   {
       super("Invalid side value:"+a);
   }

   public double getSide1()
   {
	  return side_1;
   }
   public double getSide2()
   {
	  return side_2;
   }
   public double getSide3()
   {
	  return side_3;
   }	

}
