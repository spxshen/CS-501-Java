import java.util.Scanner;
public class testTriangle
{
	 public static void main(String[] args)
	 {    
		 int repeatIntnumber = 1; 
		  Scanner in=new Scanner(System.in);//to allow user to input 
		  System.out.println("The program is going to test a designed triangle extends GeometricObject");//intro
		
		  while(repeatIntnumber==1)
		  { 
		  System.out.println("please input sides values for a triangle:");
          double side_1=in.nextDouble();//those three sides
          double side_2=in.nextDouble();
          double side_3=in.nextDouble();
       try
         {  
          
    	  Triangle obj=new Triangle(side_1,side_2,side_3);//make an object
          System.out.println("the three side of triangle is shown below:");
          System.out.println(obj.toString());//display three sides
          System.out.println("Please enter a color of the triangle:");//prompt
          String color=in.next();
          System.out.println("the color you entered is "+color);//to display
          obj.setColor(color);
          System.out.println("Please enter a Boolean value to decide whether the triangle is filled:");
          boolean fill=in.nextBoolean();
          System.out.println("Boolean value you entered is "+fill);
          obj.setFilled(fill);
          System.out.println( "The area of the triangle is: " + obj.getArea() );//as a result
          System.out.println( "The perimeter of the triangle is: " + obj.getPerimeter() );
          System.out.println( "The color of the triangle is: " + obj.getColor() );
          if(obj.isFilled())
          {
        	    System.out.println("the triangle is filled");//if true
          }
          else
          {
        	    System.out.println("the triangle is not filled");
          }
          }
          
          catch(IllegalTriangleException ex)
          {
        	  System.out.println(ex.getMessage());
          }
          System.out.println("Repeat this program (enter 1 for yes or 0 for no?): ");
          repeatIntnumber = in.nextInt();
          if (repeatIntnumber == 0)
       	   in.close();
		  }
	 }
}




