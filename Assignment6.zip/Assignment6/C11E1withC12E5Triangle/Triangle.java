
public class Triangle extends GeometricObject {

  private double side_1,side_2,side_3;//three sides
  public Triangle()//default constructor according to the question
  {
	side_1=1;   
	side_2=1;
	side_3=1;
  }
  public Triangle(double a,double b,double c)throws IllegalTriangleException
  {
	  if((a+b>c)&&(a+c>b)&&(b+c>a))
	  {
		  setSide_1(a);//set up the value
          setSide_2(b);
          setSide_3(c);
	  }
	  else//otherwise
            throw new IllegalTriangleException(a,b,c);//exception	   
  }	  
  
  public boolean isValid(double a)//to check whether the value is below zero
  {
      if(a<=0)
          return false;
      
      else
          return true;
  }
  
  public void setSide_1(double a)throws IllegalTriangleException//make sure every input is not below zero and define setters
  {
      if(!isValid(a)){
          throw new IllegalTriangleException(a);
      }
      side_1=a;
  }

  public void setSide_2(double b)throws IllegalTriangleException
  {
      if(!isValid(b)){
          throw new IllegalTriangleException(b); 
      }
      side_2=b;                                                            
  }

  public void setSide_3(double c)throws IllegalTriangleException
  {
      if(!isValid(c)){
          throw new IllegalTriangleException(c);
      }
      side_3=c;
  }
  public double getSide1()//make getter functions
  {
      return side_1;
  }

  public double getSide2()
  {
      return side_2;
  }

  public double getSide3()
  {
      return side_3;
  }
  public double getArea()//to calculate area
  {
		double s = ( side_1 + side_2 + side_3 ) / 2;
		return Math.pow( s * ( s - side_1 ) * ( s - side_2 ) * ( s -side_3 ), 0.5 );
   }
  public double getPerimeter()
  {    
	   double Perimeter=side_1 + side_2 + side_3;//sum up
	   return Perimeter;
  }
  public String toString()
  {
		return "Triangle: side1 = " + side_1 + " side2 = " + side_2 + " side3 = " + side_3; //to display those values
   }
  
}


