
public class MyRectangle2D {
private double x;
private double y;
private double width;
private double height;
public void setX(double a){
      x=a;//set x
}

public void setY(double b){
      y=b;
}
public void setWidth(double a)throws Exception
{
	if(!isValid(a))
	{
		Exception ex=new Exception("Width should be validated to be positive");//should be validated
		throw ex;
	}
	width=a;
}

public void setHeight(double b)throws Exception
{
	if(!isValid(b))
	{
		Exception ex=new Exception("Height should be validated to be positive");
		throw ex;
	}
   height=b;
}
public boolean isValid(double c)
{
    if(c<=0)
        return false;
    else
    	return true;
}
public double getX()//getter
{
    return x;//get x
}

public double getY()
{
    return y;
}

public double getWidth()
{
    return width;
}

public double getHeight()
{
    return height;
}
public MyRectangle2D(double a,double b,double c,double d)throws Exception
{//constructor with arguments
    setX(a);
    setY(b);
    setWidth(c);
    setHeight(d);
}
public MyRectangle2D()//default constructor
{
    x=0;
    y=0;
    width=1;
    height=1;
}
public double getArea()//for area
{
    return width*height;
}

public double getPerimeter()//for perimeter
{
    return (2*width+2*height);
}

public boolean contains(double x,double y)
{//from firgure 10.24 a
    if(x>this.x-this.width/2 && x<this.x+this.width/2 && y>this.y-this.height/2 && y<this.y+this.height/2)//point(x,y)is inside in the rectangle
    	return true;
    else
        return false;
}

public boolean contains(MyRectangle2D r)//function overload all the lines should be contained in bigger rectangle
{
  double x1=x-width/2;
  double x2=x+width/2;
  double y1=y-height/2;
  double y2=y+height/2;
  double x3=r.getX()-r.getWidth()/2;
  double x4=r.getX()+r.getWidth()/2;
  double y3=r.getY()-r.getHeight()/2;
  double y4=r.getY()+r.getHeight()/2;
  if(x3 >= x1 && x3 <= x2 && x4 >= x1 && x4 <= x2 && y3 >= y1 && y3 <= y2 && y4 >= y1 && y4 <= y2) 
		return true;
	else 
		return false;
    
}

public boolean overlaps(MyRectangle2D r)
{
    double x1=r.getX()-r.getWidth()/2;
    double y1=r.getY()+r.getHeight()/2;
    double x2=r.getX()+r.getWidth()/2;
    double y2=r.getY()+r.getHeight()/2;
    double x3=r.getX()-r.getWidth()/2;
    double y3=r.getY()-r.getHeight()/2;
    double x4=r.getX()+r.getWidth()/2;
    double y4=r.getY()-r.getHeight()/2;
    if(contains(x1,y1)|| contains(x2,y2)||contains(x3,y3)||contains(x4,y4))//check the specific point is inside this rectangle
       return true;
    else
       return false;
  
}
}

