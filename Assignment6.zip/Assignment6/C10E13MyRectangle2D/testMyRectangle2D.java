import java.util.Scanner;
public class testMyRectangle2D {
   public static void main(String[] args)
   {
    	  boolean loop1=true;//first is for the whole program begin and allow basic rectangle to be entered
    	  boolean loop2=true;//second is for other rectangles which are used for test points and rectangles 
    	  double x,y,width,height;
    	  MyRectangle2D base=null;//basic one
    	  MyRectangle2D test=null;//test one for contains function
    	  MyRectangle2D ovlap=null;//test one for overlaps function
    	  System.out.println("the program is going to compared basic rectangle with other test rectangles");
    	  System.out.println("At the begining, according to the question in the testbook the program should display the information below ");
    	
    	 try//this is the question from textbook
    	 {
    	  MyRectangle2D r1=new MyRectangle2D(2,2,5.5,4.9);		  
   		  System.out.println("area of MyRectangle2D(2, 2, 5.5, 4.9) is "+r1.getArea());
          System.out.println("perimeter of MyRectangle2D(2, 2, 5.5, 4.9) is "+r1.getPerimeter());
          if(r1.contains(3, 3))
          {
              System.out.println("(3,3) is in rectangle");
          }
          else
          {
              System.out.println("(3,3) is not in rectangle!");
          }
          
          if(r1.contains(new MyRectangle2D(4,5,10.5,3.2)))//contains function
         	 System.out.println("MyRectangle2D(4,5,10.5,3.2) is inside r1 rectangle");
                   
          else
              System.out.println("MyRectangle2D(4,5,10.5,3.2) is not inside r1 rectangle");
          
          if(r1.overlaps(new MyRectangle2D(3, 5, 2.3, 5.4)))
              System.out.println("MyRectangle2D(3, 5, 2.3, 5.4) overlaps with r1 rectangle");
         
          else
              System.out.println("MyRectangle2D(3, 5, 2.3, 5.4) dosen't overlap with r1 rectangle");
         
    	 }
    	 
    	 catch (Exception ex)
    	 {
    		  System.out.println(ex.getMessage());
    	 }
    	  while(loop1)//the first loop 
    	  {
    	  loop2=true;
    	  System.out.println("please input x, y, width and height for the basic rectangle");
    	  Scanner in1=new Scanner(System.in);
    	  x=in1.nextDouble();
    	  y=in1.nextDouble();
    	  width=in1.nextDouble();
    	  height=in1.nextDouble();
    	  System.out.println("the point you entered is ("+x+","+y+")");
    	  System.out.println("the width you entered is "+width);
    	  System.out.println("the height you entered is "+height);
    try{
              
    	      base=new MyRectangle2D(x,y,width,height);
    		  System.out.println("area of basic rectangle is "+base.getArea());
              System.out.println("perimeter of basic rectangle is "+base.getPerimeter());
             
         
    	  ////////////////////////////////////////////////////////////////////
     while(loop2)//second loop for all the test/nest loop
     {
    	 Scanner in2=new Scanner(System.in);
         System.out.println("please input a specific point to decide whether it is inside basic triangle:");
         x=in2.nextDouble();
         y=in2.nextDouble();
         System.out.println("("+x+","+y+")");
         if(base.contains(x, y))
         {
             System.out.println("the point you entered is in rectangle");
         }
         else
         {
             System.out.println("the point you entered is not in rectangle!");
         }
         System.out.println("please input x,y,width and height values for test rectangle to decide whether the test rectangle is inside: ");
         Scanner in3=new Scanner(System.in);
         x=in3.nextDouble();
         y=in3.nextDouble();
         width=in3.nextDouble();
         height=in3.nextDouble();
   	     System.out.println("the point you entered is ("+x+","+y+")");
	     System.out.println("the width you entered is "+width);
	     System.out.println("the height you entered is "+height);
         try
         {
             test=new MyRectangle2D(x,y,width,height);//any object buidling need try
             if(base.contains(test))
            	 System.out.println("test rectangle is inside basic rectangle");
     
             else
                 System.out.println("test rectangle is not inside basic rectangle");
         }
         catch (Exception ex)
         {
             System.out.println(ex.getMessage());
         }
        
         System.out.println("please input x,y,width and height values for test rectangle to decide whether the test rectangle overplaps with basic one: ");
         Scanner in4=new Scanner(System.in);
         x=in4.nextDouble();
         y=in4.nextDouble();
         width=in4.nextDouble();
         height=in4.nextDouble();
   	     System.out.println("the point you entered is ("+x+","+y+")");
	     System.out.println("the width you entered is "+width);
	     System.out.println("the height you entered is "+height);
         try
         {
             ovlap=new MyRectangle2D(x,y,width,height);//overlap function
             if(base.overlaps(ovlap))
                 System.out.println("test rectangle overlaps with base rectangle");
            
             else
                 System.out.println("test rectangle dosen't overlap with base rectangle");
         }
         catch (Exception ex)
         {
             System.out.println(ex.getMessage());
         }
        
    	 
         System.out.println("enter y continue test or n to stop the test:");
         Scanner in5=new Scanner(System.in);
         String label=in5.next();
         if(label.toLowerCase().equals("n"))
         {
             loop2=false;
         }
    	 
       }
    	 
   }
    	 catch (Exception ex)
    	 {
    		  System.out.println(ex.getMessage());
    	 }
    	
         System.out.println("enter y to make a new basic rectangle or n to exit the program:");//for loop
         Scanner in6=new Scanner(System.in);
         String string=in6.next();
         if(string.toLowerCase().equals("n"))
         {
             loop1=false;
         }
    }  	 
    	  
   }
		
}


