#pragma once//group 30 Pengxiang Shen + Zengrui Liu + Borui Xia
#ifndef __MYSTRING_H__
#define __MYSTRING_H__
#include <iostream>
#include <sstream>
using namespace std;
class String {
public:
	String(const char *str, bool pascal);
private:
	// arr implements the String object as a dynamic array
	char *arr;
	// len keeps track of the length
	int len;
};

String::String(const char *str, bool pascal) {
	if (pascal == true)//is a pascal string
	{
		int lenstr = str[0] - 48;//the first byte is the length
		if (lenstr < 0 || lenstr>9)//if the length is shorter than 0 or longer than 9, return
		{
			return;
		}
		else {
			arr = new char[lenstr + 1];//store the accurate string (only the length of string.)
			for (int i = 0; i < lenstr; i++)
			{
				if (str[i + 1] == '\0')//if the length is shorter than the first byte indicated, return.
					return;
				else
				{
					arr[i] = str[i + 1];//if the length is longer than the first byte indicated, get the proper string
				}
			}
			arr[lenstr] = '\0';
			len=lenstr;
		}
	}
	
	else
	{
		int lenstr = 0;
		while (str[lenstr] != '\0')//store the accurate string
		{
			lenstr++;
		}
		arr = new char[lenstr + 1];
		//std::copy(str, str + len + 1, arr);
		for (int i = 0; i < lenstr + 1; i++)
		{
			arr[i] = str[i];//copy the string
		}
		len = lenstr;
	}
}
#endif
