public class Rectangle{
	private double height;
	private double width;
	private String errorMessage="";
	
    public Rectangle()//default one
    {
    	height=1.0;
    	width=1.0;
    }
	public Rectangle(double a,double b)throws Exception{ //arguments are width and height and the constructor is overrided
		setWidth(a);
		setHeight(b);
		
	}
	public double getArea()// computing area
	{
		
		return height*width;
	}
	public double getPerimeter()// to calculate perimeter
	{
		return 2*(height+width);
		
	}
	public double getHeight() 
	{
	    return height;
	}
	public double getWidth()
	{
	    return width;
	}
    public void setWidth(double a)throws Exception{
        if(!isValidWidth(a)){
            Exception ex=new Exception(errorMessage);
            throw ex;
        }
        this.width=a;
    }
    public void setHeight(double b)throws Exception{
        if(!isValidHeight(b)){
            Exception ex=new Exception(errorMessage);
            throw ex;
        }
        this.height=b;
    }
    public boolean isValidWidth(double w)//to decide whether width is an valid input
    {
    	if(w<=0)
    	{	
    		errorMessage="The value of width is below zero so it is invalid";
    	    return false;
    	}
    	else 
    		return true;
    }
    public boolean isValidHeight(double h)//to decide whether height is an valid input
    {
    	if(h<=0)
    	{	
    		errorMessage="The value of height is below zero so it is invalid";
    	    return false;
    	}
    	else 
    		return true;
    }
    	
}


