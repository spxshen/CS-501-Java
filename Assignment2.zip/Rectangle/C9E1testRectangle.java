import java.util.Scanner;



public class C9E1testRectangle{	
  public static void main(String[] arg)throws Exception{
  Scanner in=new Scanner(System.in);
  int repeatIntnumber=1;//for loop
   while (repeatIntnumber== 1) 
    {
	  try{
		  System.out.println("This program is goint to test two rectangle objects-one with width 4 and height 40 and the other with width 3.5 and height 35.9");
		  Rectangle obj1 = new Rectangle(4.0, 40.0);//This is what the question asks for
		  System.out.println("When width is "+obj1.getWidth()+" and "+"height is "+obj1.getHeight());
		  System.out.println("The area of rectangle is " + obj1.getArea());//to show area
		  System.out.println("The perimeter of rectangle is " + obj1.getPerimeter());//to show perimeter
	    
	    }
	  catch (Exception ex){
          System.out.println(ex.getMessage());
		
	}
	  try{
		  Rectangle obj2 = new Rectangle(3.5, 35.9);//also what the question asks for
		  System.out.println("When width is "+obj2.getWidth()+" and "+"height is "+obj2.getHeight());
		  System.out.println("The area of rectangle is " + obj2.getArea());//to show area
		  System.out.println("The perimeter of rectangle is " + obj2.getPerimeter());//to show perimeter
	    
	    }
	  catch (Exception ex){
          System.out.println(ex.getMessage());
		
	}
	  try{
		 System.out.println();
		 System.out.println("you can also input the width and height to test the program");
	     System.out.println("please input width and then input height:");
	     double a=in.nextDouble();
	     double b=in.nextDouble();
	     System.out.println("width:"+a+"  heights:"+b);
	     Rectangle obj3 = new Rectangle(a, b);//this is customized object
	     System.out.println("when width is "+obj3.getWidth()+" and "+"height is "+obj3.getHeight());
		 System.out.println("The area of rectangle is " + obj3.getArea());//to show area
		 System.out.println("The perimeter of rectangle is " + obj3.getPerimeter());//to show perimeter
	     System.out.println(" Repeat program (enter 1 for yes or 0 for no? ): ");//for loop to continue or not
         repeatIntnumber = in.nextInt();
         if ( repeatIntnumber == 0)
              in.close();
	  }
	  catch (Exception ex){
          System.out.println(ex.getMessage());
          System.out.println(" Repeat program (enter 1 for yes or 0 for no? ): ");//for loop to continue or not
          repeatIntnumber = in.nextInt();
          if ( repeatIntnumber == 0)
               in.close();
	}

   }
	}
}






