import java.util.Scanner;
public class testLinearEquation// for question 9.11/9.12
{
    public static void main(String[] args)
    {
        double a,b,c,d,e,f,x1,y1,x2,y2,x3,y3,x4,y4;
        Scanner in=new Scanner(System.in);
        int repeatIntnumber=1;	//for loop
      
          while (repeatIntnumber== 1) 
          {
            try{
            	System.out.println("The linear equations are shown below:");
            	System.out.println("ax+by=e");
            	System.out.println("cx+dy=f");
            	System.out.println("The program is going to diplay the answers, x and y, of Linear Equations");
                System.out.println("Enter a,b,c,d,e,f:");
                a=in.nextDouble();
                b=in.nextDouble();
                c=in.nextDouble();
                d=in.nextDouble();
                e=in.nextDouble();
                f=in.nextDouble();
                System.out.println("a="+a+" b="+b+" c="+c+" d="+d+" e="+e+" f="+f);//display what are they
                LinearEquation obj1=new LinearEquation(a,b,c,d,e,f);//by using LinerEquation class to calculate x and y
                System.out.println("x = "+obj1.getX()+"  y = "+obj1.getY() );
              
               
            }
            
            catch (ArithmeticException ex){
                System.out.println(ex.getMessage()); //for exception
          
            }
          

            	try{

            	System.out.println();            	
            	System.out.println("The program is goint to display intersecting points of two line segments");
            	System.out.println("The two endpoints for the first line segment are (x1, y1) and (x2, y2)");
            	System.out.println("The two endpoints for the second line segment are (x3, y3) and (x4, y4)");
            	System.out.println("Enter x1,y1,x2,y2,x3,y3,x4,y4:");
                x1=in.nextDouble();
                y1=in.nextDouble();
                x2=in.nextDouble();
                y2=in.nextDouble();
                x3=in.nextDouble();
                y3=in.nextDouble();
                x4=in.nextDouble();
                y4=in.nextDouble();
                System.out.println("x1="+x1+" y1="+y1+" x2="+x2+" y2="+y2+" x3="+x3+" y3="+y3+" x4="+x4+" y4="+y4);//display what are they
                a=y1-y2;
                b=x2-x1;
                c=y3-y4;
                d=x4-x3;
                e=(y1-y2)*x1-(x1-x2)*y1;
                f=(y3-y4)*x3-(x3-x4)*y3;
                LinearEquation obj2=new LinearEquation(a,b,c,d,e,f);
                System.out.println("The two endpoints for intersecting point are ("+obj2.getX()+","+obj2.getY()+")");//to show interesecting point
                System.out.println(" Repeat program (enter 1 for yes or 0 for no? ): ");//for loop to continue or not
                repeatIntnumber = in.nextInt();
                if ( repeatIntnumber == 0)
                     in.close();
               

            }
            catch(ArithmeticException ex)
            {
            	 System.out.println("The two line segments are parallel!"); //if ad-bc=0 which means two line segements are completely parallel
            	 System.out.println("Repeat program (enter 1 for yes or 0 for no? ): ");//for loop to continue or not
                 repeatIntnumber = in.nextInt();
                 if ( repeatIntnumber == 0)
                      in.close();
                 
            	
            }
           
       }
    }
}
