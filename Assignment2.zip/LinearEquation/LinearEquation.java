public class LinearEquation{
private double a, b, c, d, e, f;
public LinearEquation(double va,double vb, double vc, double vd, double ve, double vf)//constructor takes all the variables to a b c d e f
{
	a=va; b=vb; c=vc; d=vd; e=ve; f=vf;
}
public double geta()
{
	return a;
}
public double getb()
{
	return b;
}
public double getc()
{
	return c;
}
public double getd()
{
	return d;
}
public double gete()
{
	return e;
}
public double getf()
{
	return f;
}
public boolean isSolvable()//to decide whether (ad-bc) is equal to zero or not
{
	if(a*d-b*c!=0)
	   return true;
	else
	   return false;
}	
public double getX(){
    if(isSolvable()){
        return (e*d-b*f)/(a*d-b*c); //this is the answer for X
    }
    else{
        throw new ArithmeticException("The equation has no solution");
    }
}
public double getY(){
    if(isSolvable()){
        return (a*f-e*c)/(a*d-b*c);//this is the answer for Y
    }
    else{
        throw new ArithmeticException("The equation has no solution");
    }
}
}	
	
