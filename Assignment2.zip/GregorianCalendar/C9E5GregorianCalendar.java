import java.util.GregorianCalendar;
public class C9E5GregorianCalendar extends GregorianCalendar
{
private int year;
private int month;
private int day;

public int getDay()
{
	return get(GregorianCalendar.DAY_OF_MONTH); //by using GregorianCalendar to return day
	
}
public int getMonth()
{
	return get(GregorianCalendar.MONTH)+1;//return month adding one cause first month starts from zero
	
}
public int getYear()
{

	return get(GregorianCalendar.YEAR);//return year
	
}
}
