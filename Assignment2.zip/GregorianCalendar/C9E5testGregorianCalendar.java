import java.util.GregorianCalendar;
public class C9E5testGregorianCalendar
{ 
	public static void main(String[] arg)
	{
		C9E5GregorianCalendar obj1=new C9E5GregorianCalendar();//build an object
		System.out.println("Current year is "+obj1.getYear()+" and month is "+obj1.getMonth()+" and day is "+obj1.getDay());//display year,month and day
	   
		C9E5GregorianCalendar obj2=new C9E5GregorianCalendar();
	    obj2.setTimeInMillis(1234567898765L);
	    System.out.println("After setting the value to 1234567898765L the year is "+obj2.getYear()+" and month is "+obj2.getMonth()+" and day is "+obj2.getDay());
	    //display year, month and day after setting the value
    }
}
