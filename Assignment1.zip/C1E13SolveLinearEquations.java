import java.util.Scanner;;
public class C1E13SolveLinearEquations {
    public static void main(String args[]){

        
     	double a,b,c,d,e,f,x,y;
     	System.out.println("The Linear Equations as below:");
     	System.out.println("ax+by=e"+'\n'+"cx+dy=f");
     	System.out.println("Plz Input a, b, e one by one in the first equation:");
     	Scanner input=new Scanner(System.in);//input1 is object of Scanner and then initialize it. 
     	a=input.nextDouble();//To store the inputed number in variable a
     	b=input.nextDouble();
     	e=input.nextDouble();
    	System.out.println("The first Linear Equations as below:");//just show the equation
     	System.out.println(a+"x+"+b+"y="+e);
     	System.out.println("plz Input c, d, f one by one in the second equation:");
     	c=input.nextDouble();
        d=input.nextDouble();
     	f=input.nextDouble();
    	System.out.println("The second Linear Equations as below:");
     	System.out.println(c+"x+"+d+"y="+f);
     	System.out.println("the final results are below:");
        if(a*d-b*c==0)
        	System.out.println("Error Equation!");//denominator is not equal to zero 
        else
            System.out.println("x="+(e*d-b*f)/(a*d-b*c)+'\n'+"y="+(a*f-e*c)/(a*d-b*c));	
    


    }
}
