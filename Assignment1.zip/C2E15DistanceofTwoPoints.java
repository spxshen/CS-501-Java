
import java.util.Scanner;
public class C2E15DistanceofTwoPoints {
	    public static void main(String args[]){
	    	double X1,X2,Y1,Y2;
	        Scanner a=new Scanner(System.in);
	    	System.out.println("Input first point:");
	        System.out.println("Enter X1 and Y1:");
	        X1=a.nextDouble();
	        Y1=a.nextDouble();
	        System.out.println("X1="+X1+"   Y1="+Y1); //echo what are the value of x and y 
	        System.out.println("Input second point:");
	    	System.out.println("Enter X2 and Y2:");
	    	X2=a.nextDouble();
	    	Y2=a.nextDouble();
	    	System.out.println("X2="+X2+"   Y2="+Y2);
	    	System.out.println("The distance between the two points is "+
	    	Math.pow((Math.pow(X2-X1,2)+Math.pow(Y2-Y1,2)),0.5)
	    			);

	    }

}
